import warnings
warnings.filterwarnings("ignore")

from utilities.functionXGBoost import *
from algorithms.GMO import GMO  # 从本地文件夹导入GMO
from utilities.build_model_comparison import *
from utilities.metrics import *
from utilities.load_datasets import *

import xgboost as xgb
# import LightGBM as lgb
from xgboost import XGBClassifier

import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import metrics
import time  # 时间模块
start_time = time.time()  # 获取当前时间

max_iter = 10
function = XGBoost(6)
# 搜索空间每维变量上下界
temp = [1, 7, 1, 1, 10, 1000]
varmax = np.array([temp])
temp = [0.1, 1, 0.6, 0.6, 1, 50]
varmin = np.array([temp])

gmo = GMO(30, function, max_iter)

pos_vector, velmax, velmin = gmo.initial_population(varmax, varmin)  # 种群初始化

t = 0
fitness = np.arange(max_iter + 1)  # 创建一个从0到"max_iter”（包含）的整数数组

# for saving in csv
# print(fitness)
'预设矩阵'
best_objective = np.zeros(max_iter + 1)
best_fitness = np.zeros(max_iter + 1)
iteration = [None] * (max_iter + 1)
# auc_score = [None] * (max_iter + 1)
ap = [None] * (max_iter + 1)  # average micro precision平均微精度
# cohen_kappa = [None] * (max_iter + 1)
# fpr = [None] * (max_iter + 1)
# tpr = [None] * (max_iter + 1)
# 六个参数
learning_rate = [None] * (max_iter + 1)
min_child_weight = [None] * (max_iter + 1)
subsample = [None] * (max_iter + 1)
colsample_bytree = [None] * (max_iter + 1)
max_depth = [None] * (max_iter + 1)
n_estimators = [None] * (max_iter + 1)

while t <= max_iter:
    iteration[t] = t + 1
    gmo.update_position(t, max_iter, pos_vector, velmax, velmin)  # 更新
    gmo.sort_population()  # sort是否影响结果

    print(f'Global best at iteration {t}: {gmo.get_global_best()}')
    print(f'Global best at iteration {t}: {gmo.get_global_best_params()}')
    print(f'Global best metrics at iteration {t}: {gmo.get_all_global_best_metrics()}')
    objective = gmo.get_all_global_best_metrics()

    best_objective[t] = gmo.get_global_best()
    best_fitness[t] = gmo.get_global_best_fitness()
    # ap[t] = acc
    # auc_score[t] = auc
    # cohen_kappa[t] = cohen
    # fpr[t] = fprr
    # tpr[t] = tprr

    # best parameters
    best_params = gmo.get_global_best_params()
    learning_rate[t] = best_params[0]
    min_child_weight[t] = best_params[1]
    subsample[t] = best_params[2]
    colsample_bytree[t] = best_params[3]
    max_depth[t] = best_params[4]
    n_estimators[t] = best_params[5]

    t += 1

# ============================== 循环结束 ============================================== #
# 打印
end_time = time.time()  # 获取当前时间
execute_time = end_time - start_time  # 计算迭代运行的时间
print(f"Elapsed time: {execute_time} seconds")

print("GLOBAL BEST AT THE END")
print(gmo.get_global_best())
# print(sca.get_best_solutions())
print(gmo.get_global_best_params())
print(gmo.get_all_global_best_metrics())
# 记录每一代的参数设置和平均精微度
metrics = pd.DataFrame({
    'iteration': iteration,
    'objective': best_objective,
    # 'AUC': auc_score,
    'ap': ap,
    # 'cohen': cohen_kappa,
    # 'fpr': fpr,
    # 'tpr': tpr,
    'max_depth': max_depth,
    'learning_rate': learning_rate,
    'min_child_width': min_child_weight,
    'subsample': subsample,
    'colsample_bytree': colsample_bytree,
    'n_estimators': n_estimators,
    'Elapsed time': execute_time
})  # 存每一代的适应度和参数变化
metrics.to_csv('experiment_stanisic.csv')  # 实验结果存到本地
objective = gmo.get_all_global_best_metrics()
global_best_parameters = gmo.get_global_best_params()
global_best_model = gmo.get_global_best_model()

# ============================================================================================ #
# =====上面是通过用SI训练分类器的过程，得到最优参数，下面是用最优参数带入到分类器然后得到运行结果========= #
# ============================================================================================ #
# 使用最优参数组合再运行一次
x_train, y_train, x_test, y_test = load_data()

d_train = xgb.DMatrix(x_train, label=y_train)
d_test = xgb.DMatrix(x_test, label=y_test)

x = global_best_parameters

x[4] = int(np.round(x[4], 0))
x[5] = int(np.round(x[5], 0))
# 输入 XGBoost 的超参数
params = {
    'booster': 'gbtree',
    'max_depth': x[4],
    'learning_rate': x[0],
    'sample_type': 'uniform',
    'normalize_type': 'tree',
    # 'objective': 'binary:hinge',
    'rate_drop': 0.1,
    'n_estimators': x[5],
    'min_child_weight': x[1],
    'subsample': x[2],
    'colsample_bytree': x[3],
    'random_state': 23,
    'seed': 23,
    'num_class': 15,
    # 'num_boost_round':10,
    'objective': 'multi:softprob'
}

global_best_model = xgb.train(params, d_train)  # 训练模型

preds_proba = global_best_model.predict(d_test)  # 使用模型进行预测
preds = np.argmax(preds_proba, axis=1)

# target_names = ['Normal', 'DoS', 'Probe', 'R2L', 'U2R']
# n_classes = 5
# target_names = ['Normal', 'Attack']
# n_classes = 2
target_names = ['Normal', 'Attack1', 'Attack2', 'Attack15',  'Attack4', 'Attack5', 'Attack6', 'Attack7', 'Attack8',
                'Attack9', 'Attack10', 'Attack11', 'Attack12', 'Attack13', 'Attack14']
n_classes = 15
average_precision_micro, average_precision, precision, recall, auc_score, f1_result = calculate_average_precision_all_classes_best_model_f1(
    n_classes, y_test, preds_proba, preds,
    target_names)

print("AP micro", average_precision_micro)
print("AP classes", average_precision)
print("F1 result", f1_result)

average_precision = list(average_precision.values())
average_precision = np.array(average_precision)

f1_result = list(f1_result.values())
f1_result = np.array(f1_result)

best_metrics = pd.DataFrame({
        'AP classes': average_precision
})
best_metrics.to_csv('best_model_params_AP_classes.csv')

best_metrics = pd.DataFrame({
    'F1 scores:': f1_result,
})
best_metrics.to_csv('best_model_params_F1_classes.csv')

best_metrics = pd.DataFrame({
     'max_depth': x[4],
    'learning_rate': x[0],
    'min_child_width': x[1],
    'subsample': x[2],
    'colsample_bytree': x[3],
    'n_estimators': x[5]
}, index=[0])
best_metrics.to_csv('best_model_AP_micro_all_parameters.csv')
# xgb_clf = xgb.XGBClassifier(**params)
