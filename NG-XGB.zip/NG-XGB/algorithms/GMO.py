import math
from utilities.solution import Solution
import random  # all random should be updated by numpy (faster calculation)
import copy
import numpy as np

class GMO:
    def __init__(self, n, function, max_iter):

        self.N = n  # 种群规模
        self.function = function
        self.population = []
        # self.best_solution = [None] * self.function.D  # ！

        self.pp_pbest = np.zeros([self.N, self.function.D])  # 定义所有个体的历史最优序列
        self.pp_kbest = np.zeros([self.N, self.function.D])  # 定义精英解的个体历史最优序列
        # self.pp_guide = np.zeros(self.N, self.function.D)
        # self.mutant = np.zeros(1, self.function.D)  # 高斯变异个体
        # self.stdev2 = np.zeros(self.function.D)
        self.fit = np.zeros([max_iter+1, self.N])
        # self.DFI = np.zeros(self.N)
        self.optimal_pos = np.zeros([self.N])  # 定义种群历史最优序列
        self.z_pbest = np.zeros([self.N])  # 定义所有个体的历史最优适应度
        self.z_kbest = np.zeros([self.N])  # 定义精英解的个体历史最优适应度
        self.z_optimal = np.zeros([self.N])  # # 定义种群历史最优适应度
        self.z_iter = np.zeros([self.N])



    # 定义种群初始化方式
    def initial_population(self, varmax, varmin):
        for i in range(0, self.N):
            local_solution = Solution(self.function)
            self.population.append(local_solution)  # 向list末尾处添加local_solution（解的适应度），填充population
            self.pp_pbest[i] = local_solution.x  # 存入每个个体历史最优序列
            self.z_pbest[i] = local_solution.objective_function  # 存入每个个体历史最优适应度

        self.population.sort(key=lambda x: x.fitness)  # 根据fitness适应度排序
        self.best_solution = copy.deepcopy(self.population[-1].x)  # 将最优解拷贝给best_solution（获取最优个体）
        limvel = 0.1
        velmax = limvel * (varmax[0, 0:self.function.D] - varmin[0, 0:self.function.D])
        velmin = (-1) * velmax
        pos_vector = np.zeros([self.N, self.function.D])  # 初始化速度矩阵
        for i in range(0, self.N):
            pos_vector[i, :] = (velmax - velmin) * np.random.rand(1, self.function.D) + velmin

    #     for j=1:popsize
    #     z = fobj(position(j, 1:dim)); %计算适应度
    #     z_pbest(j) = z; %每个解的历史最优适应度
    #     pp_pbest(j, 1: dim)=position(j, 1: dim); %每个解的历史最优序列
    #
    # end
        # printing objective function, sorting is in the ascending order
        # for i in self.population:
        # print(i.objective_function)

        return pos_vector, velmax, velmin  # 输出初始化生成的速度矩阵
    # 定义种群更新方式
    def update_position(self, t, max_iter, pos_vector, velmax, velmin):
        Position = np.zeros([self.N, self.function.D])
        for i in range(self.N):  # 循环每一个个体
            Position[i] = copy.deepcopy(self.population[i].x)  # 提取当前个体

        kbest_max = self.N  # 设定精英解的个数（最大）
        kbest_min = 2  # 设定精英解的个数（最小）
        stdev2 = np.zeros([self.function.D, 1])

        for j in range(0, self.function.D):
            stdev2[j][0] = np.std(self.pp_pbest[0:self.N, j])  # 所有解的历史最优序列的标准差  # 需要提前计算pp_pbest

        max_stdev2 = np.max(stdev2)  # 每个解的历史最有序列的标准差的最大值
        # 平均值和标准差
        ave = np.mean(self.z_pbest[0:self.N])  # 适应度的平均值
        stdev = np.std(self.z_pbest[0:self.N])  # 适应度的标准差
        # 精英解(下面两行计算精英解的个数)
        kbest = kbest_max - (kbest_max - kbest_min) * (t / max_iter)
        n_best = round(kbest)
        index = np.zeros([self.N, 1])  # 初始化index矩阵
        # 评价解的双适应度指数 - Eq - (3)
        for j in range(0, self.N):
             index[j] = j
        for j in range(0, self.N):
            MF = 1
            for jj in range(0, self.N):
                if jj != j:
                   MF = MF * (1 / (1 + np.exp((-4) / (stdev * np.sqrt(np.exp(1))) * (self.z_pbest[jj] - ave))))  # 公式2
            # print(t)
            # print(j)
            self.fit[t, j] = MF  # 双适应度指数MF(除了适应度1的另外一个指标，通过种群个体位置的统计信息计算得到)

        # 更新index和fit
        for j in range(0, self.N - 1):
             for jj in range(j+1, self.N):
                if self.fit[t, jj] > self.fit[t, j]:
                    c1 = self.fit[t, j]
                    self.fit[t, j] = self.fit[t, jj]
                    self.fit[t, jj] = c1
                    c2 = np.copy(index[j])
                    index[j] = index[jj]
                    index[jj] = c2


        # 指定精英解决解
        sum1 = 0
        # index1 = index[:, 0]  #
        for j in range(0, n_best):
            # a = index[j]
            self.z_kbest[j] = self.z_pbest[int(index[j][0])]
            self.pp_kbest[j, 0: self.N] = self.pp_pbest[int(index[j][0]), 0: self.function.D]
            sum1 = sum1 + self.fit[t, j]
        pp_guide = np.zeros([self.N, self.function.D])
        DFI = np.zeros([self.N, 1])
        epsilon = 0  # GMO的一个参数
        # 双指标适应度得到fit，然后精英解，最终得到导向解
        # 计算导向解
        for j in range(0, self.N):
            pp_guide[j, 0: self.function.D] = np.zeros([1, self.function.D])  # 每次计算前先赋0
            for jj in range(0, n_best):
                 if int(index[jj]) != j:
                    DFI[jj] = self.fit[t, jj] / (sum1 + epsilon)
                    pp_guide[j, 0: self.function.D] = pp_guide[j, 0: self.function.D]+DFI[jj] * self.pp_kbest[jj, 0: self.function.D]  # Eq.(5)


        t = t + 1  # 迭代次数+1
        w = 1 - (t / max_iter)  # Eq.(9) np.random.rand(rows, cols)
        mutant = np.zeros([1, self.function.D])  # 初始化矩阵高斯变异个体

        ' 个体位置更新 '
        for j in range(0, self.N):
            # Mutating the guide solutions - Eq.(6) 导向解变异
            mutant[0, 0: self.function.D] = pp_guide[j, 0: self.function.D] + w * np.random.rand(1, self.function.D) * (max_stdev2 - stdev2[:, 0])  # 高斯变异

            # Updating the velocity of the solutions - Eq.(7)
            pos_vector[0, 0: self.function.D] = w * pos_vector[j, 0: self.function.D]+(np.ones([1, self.function.D]) + (2 * np.random.rand(1, self.function.D) - np.ones([1, self.function.D])) * w) * (mutant[0, 0: self.function.D] - Position[j, 0: self.function.D])

            # 超出边界的速度变量重新定义
            for jj in range(0, self.function.D):
                if pos_vector[j, jj] < velmin[jj]:
                    pos_vector[j, jj] = velmin[jj]

                elif pos_vector[j, jj] > velmax[jj]:
                    pos_vector[j, jj] = velmax[jj]

            # 更新个体位置，公式8
            Position[j, :] = Position[j, :]+pos_vector[j, :]

            temp = [1, 7, 1, 1, 10, 1000]
            varmax = np.array([temp])
            temp = [0.1, 1, 0.6, 0.6, 1, 50]
            varmin = np.array([temp])
            # 超出边界重新定义（位置）
            for k in range(0, self.function.D):
                if Position[j, k] < varmax[0][k]:
                    Position[j, k] = varmax[0][k]

                elif Position[j, k] > varmax[0][k]:
                    Position[j, k] = varmin[0][k]
            Position1 = Position[j, :].tolist()  # 转换为list用于计算
            solution = Solution(self.function, Position1)  # 计算适应度

            if solution.fitness > self.population[j].fitness:
                self.population[j] = solution
                self.pp_pbest[j] = solution.x  # 存入每个个体历史最优序列
                self.z_pbest[j] = solution.objective_function  # 存入每个个体历史最优适应度
            # 是否增加zbest的对比
    def sort_population(self):

        self.population.sort(key=lambda x: x.fitness)
        self.best_solution = self.population[-1].x

    def get_global_best(self):
        return self.population[-1].objective_function

    def get_global_worst(self):
        return self.population[0].objective_function

    def get_global_best_fitness(self):
        return self.population[-1].fitness

    def get_global_best_params(self):
        return self.population[-1].x

    def optimum(self):
        print('f(x*) = ', self.function.minimum, 'at x* = ', self.function.solution)

    def algorithm(self):
        return 'GMO'

    def objective(self):

        result = []

        for i in range(self.N):
            result.append(self.population[i].objective_function)

        return result

    def average_result(self):
        return np.mean(np.array(self.objective()))

    def std_result(self):
        return np.std(np.array(self.objective()))

    def median_result(self):
        return np.median(np.array(self.objective()))

    def print_global_parameters(self):
        for i in range(0, len(self.best_solution)):
            print('X: {}'.format(self.best_solution[i]))

    # ovo je za sve global best metrics, fpr, tpr, etc.
    def get_all_global_best_metrics(self):
        best_sol = self.population[-1]
        return best_sol.objective_function

        # best_sol.accuracy, best_sol.auc_score, best_sol.cohen_score, best_sol.fpr, best_sol.tpr

    def get_global_best_model(self):
        best_sol = self.population[-1]
        return best_sol.model

    def get_best_solutions(self):
        return np.array(self.best_solution)

    def get_solutions(self):

        sol = np.zeros((self.N, self.function.D))
        for i in range(len(self.population)):
            sol[i] = np.array(self.population[i].x)
        return sol

    def print_all_solutions(self):
        print("******all solutions objectives**********")
        for i in range(0, len(self.population)):
            print('solution {}'.format(i))
            print('objective:{}'.format(self.population[i].objective_function))
            print('fitness:{}'.format(self.population[i].fitness))
            print('solution {}: '.format(self.population[i].x))
            print('--------------------------------------')
