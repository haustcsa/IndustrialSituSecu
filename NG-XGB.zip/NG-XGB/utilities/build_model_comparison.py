import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier
from utilities.load_datasets import *
#from utilities.load_datasets_comparisonOld import *


class Build_model_comparison:
    def __init__(self, D):
        self.D = D
        self.ub = [None] * self.D
        self.lb = [None] * self.D
        self.minimum = 0
        self.solution = '(0,...,0)'
        self.name = "XGBoost hyperparameters"
        # self.classes = 10

        (self.x_train, self.y_train, self.x_test, self.y_test) = load_data()

        # coverting train and test datasets to DMatrix

        self.d_train = xgb.DMatrix(self.x_train, self.y_train)
        self.d_test = xgb.DMatrix(self.x_test, self.y_test)

        # learning_rate [0.1 - 0.5]   [default:0.3]  float
        self.lb[0] = 0.1
        self.ub[0] = 0.5

        # min_child_weight [1-7] [default:1] float
        self.lb[1] = 1
        self.ub[1] = 7

        # subsample [0.6-1] [default:1] float
        self.lb[2] = 0.6
        self.ub[2] = 1

        # colsample_bytree[0.6 - 1][default:1] float
        self.lb[3] = 0.6
        self.ub[3] = 1

        # max_depth [1-10] integer [default:6]
        self.lb[4] = 1
        self.ub[4] = 10

        # n_estimators: [100,1000]   [default:100] int
        self.lb[5] = 50
        self.ub[5] = 1000

    def function(self, x):
        # convert float to int for [4]
        x[4] = int(np.round(x[4], 0))

        x[5] = int(np.round(x[5], 0))

        # parametri za XGBoost
        params = {
            'booster': 'gbtree',
            'max_depth': x[4],
            'learning_rate': x[0],
            'sample_type': 'uniform',
            'normalize_type': 'tree',
            'objective': 'binary:hinge',
            'rate_drop': 0.1,
            'n_estimators': x[5],
            'min_child_weight': x[1],
            'subsample': x[2],
            'colsample_bytree': x[3],
            'random_state': 23,
            'seed': 23,
            'num_boost_round': 10
        }

        # create XGBoost model
        # xgb_clf = xgb.XGBClassifier(**params)
        # xgb_clf.fit(self.x_train,self.y_train)
        # xgb_clf.fit(self.d_train)

        # make prediction
        # preds = xgb_clf.predict(self.x_test)

        #model = XGBClassifier(**params)
        #model.fit(self.x_train, self.y_train)
        #preds = model.predict(self.x_test)
        #acc = np.round(accuracy_score(self.y_test, preds) * 100, 2)
        #preds_proba = model.predict_proba(self.x_test)[:, 1]

        #auc_score = roc_auc_score(self.y_test, preds)

        #fpr, tpr, thresholds = metrics.roc_curve(self.y_test, preds_proba)

        # NOVI EFIKASNIJI NACIN



        xgb_clf = xgb.train(params, self.d_train)


        preds = xgb_clf.predict(self.d_test)
        # print accuracy score
        acc = np.round(accuracy_score(self.y_test, preds) * 100, 2)
        #print(acc)

        # building AUC
        fpr, tpr, thres = metrics.roc_curve(self.y_test, preds)

        # Area Under the Curve
        auc_score = metrics.auc(fpr, tpr)


        # cohen cappa score

        cohen_score = metrics.cohen_kappa_score(self.y_test, preds)

        # return accuracy, auc score, cohen score

        return auc_score, acc, auc_score, cohen_score, fpr, tpr
        # return acc, auc_score, cohen_score, fpr, tpr