import numpy as np
import pandas as pd

from utilities.load_datasets import *
from utilities.metrics import *
# import xgboost as xgb
import xgboost as xgb
from xgboost import XGBClassifier

import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier


class XGBoost:
    def __init__(self, D):
        self.D = D
        self.ub = [None] * self.D
        self.lb = [None] * self.D
        self.minimum = 0
        self.solution = '(0,...,0)'
        self.name = "XGBoost hyperparameters"
        # self.classes = 10

        (self.x_train, self.y_train, self.x_test, self.y_test) = load_data()

        # coverting train and test datasets to DMatrix 将训练和测试数据集转换为DMatrix

        self.d_train = xgb.DMatrix(self.x_train, label=self.y_train)
        self.d_test = xgb.DMatrix(self.x_test, label=self.y_test)

        # learning_rate [0.1 - 0.5]   [default:0.3]  float学习率
        self.lb[0] = 0.1
        self.ub[0] = 1

        # min_child_weight [1-7] [default:1] float最小叶权值
        self.lb[1] = 1
        self.ub[1] = 7

        # subsample [0.6-1] [default:1] float 随机采样率
        self.lb[2] = 0.6
        self.ub[2] = 1

        # colsample_bytree[0.6 - 1][default:1] float控制采样比例
        self.lb[3] = 0.6
        self.ub[3] = 1

        # max_depth [1-10] integer [default:6]树的最大深度
        self.lb[4] = 1
        self.ub[4] = 10

        # n_estimators: [100,1000]   [default:100] int损失函数参数  gamma
        self.lb[5] = 0
        self.ub[5] = 1000

    def function(self, x):
        # convert float to int for [4]
        x[4] = int(np.round(x[4], 0))
        # print(type(x[4]))
        # x[4] = int(x[4])
        # print(type(x[4]))
        x[5] = int(np.round(x[5], 0))
        # parametri za XGBoost
        params = {
            'booster': 'gbtree',
            'max_depth': x[4],
            'learning_rate': x[0],
            'sample_type': 'uniform',
            'normalize_type': 'tree',
            # 'objective': 'binary:hinge',
            'rate_drop': 0.1,
            'n_estimators': x[5],
            'min_child_weight': x[1],
            'subsample': x[2],
            'colsample_bytree': x[3],
            'random_state': 23,
            'seed': 23,
            'num_class': 5,
            # 'num_boost_round':10,
            'objective': 'multi:softprob'
        }

        # create XGBoost model
        #xgb_clf = xgb.XGBClassifier(**params)
        #xgb_clf.fit(self.x_train,self.y_train)
        # xgb_clf.fit(self.d_train)

        # make prediction
        #preds = xgb_clf.predict(self.x_test)

        # model = XGBClassifier(**params)
        # model.fit(self.x_train,self.y_train)
        #preds = model.predict(self.x_test)
        # acc = np.round(accuracy_score(self.y_test, preds) * 100, 2)
        #preds_proba = xgb_clf.predict_proba(self.x_test)

        # auc_score = roc_auc_score(self.y_test,preds)

        # fpr, tpr, thresholds = metrics.roc_curve(self.y_test, preds_proba)

        # NOVI EFIKASNIJI NACIN

        #xgb_clf = xgb.XGBClassifier(**params)
        xgb_clf = xgb.train(params, self.d_train)  # 用xgb训练数据集

        # predict po defaultu radi predict proba
        preds_proba = xgb_clf.predict(self.d_test)  # 用测试集来评估训练结果

        #bst = xgb.train(params, self.d_train)
        #preds_proba = bst.predict(self.d_test)

        # sada racunamo samo predictions sa arg max
        #print("GRESKA")
        #print(preds_proba)
        preds = np.argmax(preds_proba, axis=1) # 取preds_proba数组的每一行的最大值索引，作为预测结果。np.argmax函数会返回指定轴上最大值的索引。

        # print accuracy score
        # acc = np.round(accuracy_score(self.y_test, preds) * 100, 2)
        # print(acc)

        # building AUC
        # fpr, tpr, thres = metrics.roc_curve(self.y_test, preds)

        # Area Under the Curve
        # auc_score = metrics.auc(fpr, tpr)

        # cohen cappa score

        # cohen_score = metrics.cohen_kappa_score(self.y_test, preds)

        # return accuracy, auc score, cohen score

        # return auc_score,acc,auc_score,cohen_score,fpr,tpr
        # return acc, auc_score, cohen_score, fpr, tpr


        # NSL-KDD
        # target_names = ['Normal', 'DoS', 'Probe', 'R2L', 'U2R']
        # n_classes = 5
        # SWaT
        target_names = ['Normal', 'A1', 'A2', 'A3', 'A4']
        n_classes = 5
        # SWAT 2分类
        # target_names = ['Normal', 'Attack']
        # n_classes = 2
        # WADI
        # target_names = ['Normal', 'Attack1', 'Attack2', 'Attack15', 'Attack4', 'Attack5', 'Attack6', 'Attack7', 'Attack8', 'Attack9', 'Attack10', 'Attack11', 'Attack12', 'Attack13', 'Attack14']
        # n_classes = 15
        average_precision,report = calculate_average_precision_all_classes(n_classes, self.y_test, preds_proba, preds,
                                                                    target_names)

        return average_precision, xgb_clf, report
