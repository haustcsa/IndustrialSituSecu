import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# from sklearn.preprocessing import LabelEncoder


def load_data():
    # DATA FOR TRAINING
    # df_train = pd.read_csv(r'../datasets/NSL-KDDTrainNew.csv',index_col=0)
    # df_test = pd.read_csv(r'../datasets/NSL-KDDTestNew.csv', index_col=0)
    # NSL-KDD 数据集
    # df_train = pd.read_csv('D:/# 科研工作/论文学习/PeerJ-CS； IDS相关论文/一种新型混合萤火虫算法：一种增强入侵检测分类XGBoost调优的应用/datasets/datasets/NSL-KDDTrainNew.csv', index_col=0)
    # df_test = pd.read_csv('D:/# 科研工作/论文学习/PeerJ-CS； IDS相关论文/一种新型混合萤火虫算法：一种增强入侵检测分类XGBoost调优的应用/datasets/datasets/NSL-KDDTestNew.csv', index_col=0)
    # SWaT(多分类)
    df = pd.read_csv('D:/# 科研工作/# 论文原稿/1. 一种自适应的IDS/数据集/SWaT/SWaT.A1 & A2_Dec 2015/Physical-20240115T022832Z-001/Physical/SWaT_Dataset_Attack_v0.csv', index_col=0)
    X = df.drop(['label', 'Normal/Attack'], axis=1)  # 剔除非数值型维度（列）变量
    y = df['label']
    # # SWAT （2分类）
    # df = pd.read_csv('D:/# 科研工作/# 论文原稿/1. 一种自适应的IDS/数据集/SWaT/SWaT.A1 & A2_Dec 2015/Physical-20240115T022832Z-001/Physical/SWaT_Dataset_Attack_v0 - 2分类.csv', index_col=0)
    # X = df.drop(['Normal/Attack'], axis=1)  # 剔除非数值型维度（列）变量
    # y = df['Normal/Attack']

    # # WADI
    # df = pd.read_csv('D:/# 科研工作/# 论文原稿/1. 一种自适应的IDS/数据集/WADI/WADI.A2_19 Nov 2019    （新）/WADI_attackdataLABLE（已标记15次攻击）.csv', index_col=0)
    # X = df.drop(['Attack LABLE (1:No Attack, -1:Attack)','Time'], axis=1)  # 剔除非数值型维度（列）变量
    # y = df['Attack LABLE (1:No Attack, -1:Attack)']

    # WADI
    # df = pd.read_csv('D:/# 科研工作/# 论文原稿/1. 一种自适应的IDS/数据集/WADI/WADI.A2_19 Nov 2019    （新）/WADI_attackdataLABLE（已标记2次攻击）.csv', index_col=0)
    # X = df.drop(['Attack LABLE (1:No Attack, -1:Attack)','Time'], axis=1)  # 剔除非数值型维度（列）变量
    # y = df['Attack LABLE (1:No Attack, -1:Attack)']

    x_train_xgb, x_test_xgb, y_train_xgb, y_test_xgb = train_test_split(X, y, train_size=0.8, test_size=0.2,
                                                        random_state=0, shuffle=True)  # shuffle=False
    # df_train = pd.read_csv('C:/Users/ikicainele/Desktop/NIDS Project/datasets/train_raw.csv', index_col=0)
    # df_test = pd.read_csv('C:/Users/ikicainele/Desktop/NIDS Project/datasets/test_raw.csv', index_col=0)


    # u datasetu new imamo category i category encoded
    # u datasetu raw nemamo category_encoded, vec samo category
    # x_train_xgb = df_train.drop(['category', 'category_encoded'], axis=1)
    # y_train_xgb = df_train['category_encoded']
    #
    # x_test_xgb = df_test.drop(['category', 'category_encoded'], axis=1)
    # y_test_xgb = df_test['category_encoded']



    x_train_xgb.columns = x_test_xgb.columns


    return x_train_xgb, y_train_xgb, x_test_xgb, y_test_xgb
