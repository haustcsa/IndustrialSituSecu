"""
定义了三个调用函数
calculate_average_precision_all_classes
calculate_average_precision_all_classes_best_model
calculate_average_precision_all_classes_best_model_f1
"""
def calculate_average_precision_all_classes(n_classes, y_test, y_proba, y_pred, target_names):
    """
    作用：用于评估每个粒子的适应度

    输入： 分类数； 测试集标签 测试结果分类概率 测试集得到的预测值 分类类别名字
    """

    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import average_precision_score, classification_report
    import matplotlib.pyplot as plt
    from sklearn.metrics import f1_score
    from sklearn.metrics import auc
    import numpy as np
    import pandas as pd

    n_classes = n_classes
    # For each class
    precision = dict()
    recall = dict()
    average_precision = dict()
    auc_score = dict()
    f1_result = dict()
    # transofrming y_test into dummy
    x = pd.get_dummies(y_test)
    x = np.array(x)

    y = pd.get_dummies(y_pred)
    y = np.array(y)
    # 计算每个分类的值
    for i in range(n_classes):
        # 1 - 计算 p 和 r 两个指标值
        precision[target_names[i]], recall[target_names[i]], _ = precision_recall_curve(x[:, i], y_proba[:, i])
        # 2 - 计算平均精度
        average_precision[target_names[i]] = average_precision_score(x[:, i], y_proba[:, i])
        # 3 - 计算auc得分 - 根据每个分类的 r 和 p
        auc_score[target_names[i]] = auc(recall[target_names[i]], precision[target_names[i]])
        # 4 - 计算f1
        # f1_result[target_names[i]] = f1_score(x[:, i], y[:, i])
    # micro value 每个分类的平均值
    precision["micro"], recall["micro"], _ = precision_recall_curve(x.ravel(), y_proba.ravel())
    average_precision["micro"] = average_precision_score(x, y_proba, average="micro")
    report = classification_report(y_test, y_pred, output_dict=True)
    return average_precision["micro"], report


# def calculate_average_precision_all_classes_best_model(n_classes, y_test, y_proba, y_pred, target_names):
#     from sklearn.metrics import precision_recall_curve
#     from sklearn.metrics import average_precision_score
#     import matplotlib.pyplot as plt
#     from sklearn.metrics import f1_score
#     from sklearn.metrics import auc
#     import numpy as np
#     import pandas as pd
#
#     # n_classes = n_classes
#     # For each class
#     precision = dict()
#     recall = dict()
#     average_precision = dict()
#     auc_score = dict()
#     f1_result = dict()
#     # transofrming y_test into dummy
#     x = pd.get_dummies(y_test)
#     x = np.array(x)
#
#     y = pd.get_dummies(y_pred)
#     y = np.array(y)
#     # 循环每个分类
#     for i in range(n_classes):
#         precision[target_names[i]], recall[target_names[i]], _ = precision_recall_curve(x[:, i],
#                                                                                         y_proba[:, i])
#         average_precision[target_names[i]] = average_precision_score(x[:, i],
#                                                                      y_proba[:, i])
#
#         # auc_score i isto sto i average_precision
#         # average_precision je Area Under the Curve za pojedinacne klase, ovo je dobro
#         auc_score[target_names[i]] = auc(recall[target_names[i]], precision[target_names[i]])
#
#         # f1_result[target_names[i]] = f1_score(x[:, i], y[:, i])
#
#         plt.plot(precision[target_names[i]], recall[target_names[i]], lw=1,
#                  label='{} AP:{:.2f}'.format(target_names[i], average_precision[target_names[i]]))
#
#     # A "micro-average": quantifying score on all classes jointly
#     precision["micro"], recall["micro"], _ = precision_recall_curve(x.ravel(),
#                                                                     y_proba.ravel())
#     average_precision["micro"] = average_precision_score(x, y_proba,
#                                                          average="micro")
#
#     plt.axhline(y=average_precision["micro"], lw=1, linestyle='--',
#                 label='{} AP:{:.2f}'.format("Micro", average_precision["micro"]))
#
#     # stampanje micro PR krive
#     plt.plot(precision["micro"], recall["micro"], lw=1,
#              label='{} AP:{:.2f}'.format("AP micro", average_precision["micro"]))
#
#     plt.xlabel("recall")
#     plt.ylabel("precision")
#     plt.legend(loc="best")
#     plt.title("precision vs. recall curve")
#     plt.savefig('dmatrix model.pdf')
#     plt.show()
#
#     print('Average precision score, micro-averaged over all classes: {0:0.2f}'
#           .format(average_precision["micro"]))
#     # vraca average precision za sve klase i precision i recall za posebne klase
#     # dodatno vraca i auc score i f1_score
#     return average_precision["micro"], average_precision, precision, recall, auc_score, f1_result
#     # return average_precision["micro"]


def calculate_average_precision_all_classes_best_model_f1(n_classes, y_test, y_proba, y_pred, target_names):
    """
    can be used for calculating fitness function
    函数:用于计算所有分类的平均精度precision
    inputs:
    n_classes    -  分类个数
    y_test       -  测试集标签
    y_proba      -  预测概率
    y_pred       -  被分类编号
    target_names -  分类标签
    """
    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import average_precision_score
    import matplotlib.pyplot as plt
    from sklearn.metrics import f1_score
    from sklearn.metrics import auc
    import numpy as np
    import pandas as pd
    from sklearn.metrics import accuracy_score, classification_report, recall_score, precision_score
    from sklearn.metrics import confusion_matrix

    # For each class
    precision = dict()
    recall = dict()
    average_precision = dict()
    auc_score = dict()
    f1_result = dict()
    acc_result = dict()
    # transofrming y_test into dummy
    x = pd.get_dummies(y_test)  # 转换为TF值
    x = np.array(x)  # 转换 矩阵形式

    y = pd.get_dummies(y_pred)
    y = np.array(y)
    for i in range(n_classes):  # x是真实值 y是预测值，可以在这里加入acc
        precision[target_names[i]], recall[target_names[i]], _ = precision_recall_curve(x[:, i], y_proba[:, i])
        average_precision[target_names[i]] = average_precision_score(x[:, i], y_proba[:, i])  # 计算当前分类的平均精准度
        acc_result[target_names[i]] = accuracy_score(x[:, i], y[:, i])
        # auc_score i isto sto i average_precision
        # average_precision je Area Under the Curve za pojedinacne klase, ovo je dobro
        auc_score[target_names[i]] = auc(recall[target_names[i]], precision[target_names[i]])
        try:  # 计算当前分类的f1值
            f1_result[target_names[i]] = f1_score(x[:, i], y[:, i])
        except:
            f1_result[target_names[i]] = 0
        # 画每个分类的 P - R 曲线
        plt.plot(precision[target_names[i]], recall[target_names[i]], lw=1, label='{} AP:{:.2f}'.format(target_names[i], average_precision[target_names[i]]))
    # 可以计算完每个分类的值之后下面求各自的平均值然后输出
    # 计算 micro precision
    precision["micro"], recall["micro"], _ = precision_recall_curve(x.ravel(), y_proba.ravel())
    average_precision["micro"] = average_precision_score(x, y_proba, average="micro")
    f1_micro = f1_score(y_test, y_pred, average='micro')  # micro f1
    recall_micro = recall_score(y_test, y_pred, average='micro')
    precision_micro = precision_score(y_test, y_pred, average='micro')
    report = classification_report(y_test, y_pred, output_dict=True)
    average_accuracy = report['accuracy']

    # 画PR曲线图
    plt.axhline(y=average_precision["micro"], lw=1, linestyle='--',
                label='{} AP:{:.2f}'.format("Micro", average_precision["micro"]))

    # stampanje micro PR krive
    plt.plot(precision["micro"], recall["micro"], lw=1,
             label='{} AP:{:.2f}'.format("AP micro", average_precision["micro"]))

    plt.xlabel("recall")
    plt.ylabel("precision")
    plt.legend(loc="best")
    plt.title("precision vs. recall curve")
    plt.savefig('PR curve model.pdf')
    plt.show()

    print('Average precision score, micro-averaged over all classes: {0:0.2f}'
          .format(average_precision["micro"]))
    # 绘制混淆矩阵图
    # classes = ['Normal', 'Attack']
    # classes = ['A1', 'A2', 'A3', 'A4', 'A5']
    classes = ['N', 'A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9', 'A10', 'A11', 'A12', 'A13', 'A14']
    confusion = confusion_matrix(y_test, y_pred)

    # 绘制热度图
    plt.imshow(confusion, cmap=plt.cm.Blues)
    indices = range(len(confusion))
    plt.xticks(indices, classes)
    plt.yticks(indices, classes)
    plt.colorbar()
    plt.xlabel('y_pred')
    plt.ylabel('y_true')

    # 显示数据
    for first_index in range(len(confusion)):
        for second_index in range(len(confusion[first_index])):
            plt.text(first_index, second_index, confusion[first_index][second_index])

    # 显示图片
    plt.show()

    return average_precision["micro"], average_precision, precision, recall, auc_score, f1_result, acc_result

