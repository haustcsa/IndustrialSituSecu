import numpy as np

class Solution:
    def __init__(self, function, x=None):
        if x is None:
            self.function = function
            self.x = [None] * self.function.D  
            self.objective_function = None
            self.fitness = None
            #self.accuracy = None
            self.ap = None #ovo je average precision
            #self.auc_score = None
            #self.cohen_score = None
            #self.fpr = None
            #self.tpr = None
            self.initialize()
            self.trial = 0
            self.model = None
        else:
            self.x = x
            self.function = function
            self.calculate_objective_function()
            self.calculate_fitness()
            self.trial = 0

      

    def initialize(self):        
        for i in range(0, len(self.x)):
            rnd = np.random.rand()
            self.x[i] = rnd * (self.function.ub[i] - self.function.lb[i]) + self.function.lb[i]  # 每一维数据的生成在解空间内生成随机数
        #self.x[4] = int(np.round(self.x[4],0))

        self.calculate_objective_function()
        self.calculate_fitness()
        

    def calculate_objective_function(self):
        self.ap = self.function.function(self.x)
        self.objective_function, self.model, self.report = self.function.function(self.x)
        #self.objective_function,self.accuracy,self.auc_score,self.cohen_score,self.fpr,self.tpr= self.function.function(self.x)
        self.fitness = 1+abs(self.objective_function)
        #self.fitness = 1 / (1 + abs(self.objective_function))

    def calculate_fitness(self):
        #self.fitness = 1 / (1 + abs(self.objective_function))
        self.fitness = 1 + abs(self.objective_function)
        

